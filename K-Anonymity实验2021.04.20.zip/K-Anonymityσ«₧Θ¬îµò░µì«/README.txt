adult.data是数据集，来自https://archive.ics.uci.edu/ml/datasets/adult 
Attributes包括'age', 'work_class', 'final_weight', 'education',
            'education_num', 'marital_status', 'occupation', 'relationship',
            'race', 'sex', 'capital_gain', 'capital_loss', 'hours_per_week',
            'native_country', 'class'
adult_*.txt: 每行两个字符串，以','分隔，第一个表示子节点，第二个表示父节点。